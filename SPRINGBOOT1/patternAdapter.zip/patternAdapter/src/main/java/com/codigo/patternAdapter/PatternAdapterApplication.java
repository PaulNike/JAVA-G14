package com.codigo.patternAdapter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatternAdapterApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatternAdapterApplication.class, args);
	}

}
